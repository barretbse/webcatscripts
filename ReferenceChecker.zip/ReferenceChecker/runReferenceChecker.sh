export JAVA_HOME=/app/oracle/biee/oracle_common/jdk/
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=$CLASSPATH:$JAVA_HOME/lib

echo "Start time: `date`"
java -jar ReferenceChecker.jar "localhost" "7780" "weblogic" "Admin123" "/shared" |tee output.txt
echo "End time: `date`"

