#!/bin/sh

#--------------------Set env variables--------------------
#IMPORTANT: Key in correct values for the following environment variables

DBCONNECTION="BIEE_BIPLATFORM/Admin123@PDBORCL"
MYPATH="/app/oracle/SAScripts/ReferenceChecker"
#--------------------Cleanup old logs and bad files --------------------
cd $MYPATH
rm -f log/* bad/* 

sqlldr $DBCONNECTION control=ctl/load_results.ctl log=log/load_results.log
sqlldr $DBCONNECTION control=ctl/load_search_pattern.ctl log=log/load_search_pattern.log

#--------------------Printing logs--------------------
tail log/*
#--------------------End of Script --------------------
