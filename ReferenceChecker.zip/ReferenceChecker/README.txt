This utility searches through object XML of each Presentation Catalog objects and reports the occurrence(s) of a search string supplied to it as a REGEX pattern. If the search is for Presentation Catalog references, the utility goes ahead and checks the validity of the target object and reports it as valid or broken. 

Execute "runReferenceChecker.sh" to search through the catalog. Then run "load_results.sh" file to upload its result into database. BI reports built on top of this data are saved under "/shared/9. Lifecycle and Admin/_portal/9.40 Webcat References Checker".

Regular expression pattern used in the search is specified in the input file "regex.txt".

Details of searched catalog Objects:
 - Source Name
 - Signature
 - Source Path
 - Path-Level0
 - Path-Level1
 - Path-Level2
 - Path-Rest

Search Results:
 - Target Path
 - Target Status

