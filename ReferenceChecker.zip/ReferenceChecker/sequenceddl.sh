#!/bin/sh

#--------------------Set env variables--------------------
#IMPORTANT: Key in correct values for the following environment variables

DBCONNECTION="BIEE_BIPLATFORM/Admin123@PDBORCL"

#--------------------Execute SQL Scripts------------------
sqlplus $DBCONNECTION <<ENDOFSQL

CREATE SEQUENCE REF_SEQ 
START WITH 1000 INCREMENT BY 2 MAXVALUE 999990 CYCLE;

/
ENDOFSQL

#--------------------End of Script --------------------
