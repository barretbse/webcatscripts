#!/bin/sh

#--------------------Set env variables--------------------
#IMPORTANT: Key in correct values for the following environment variables

DBCONNECTION="BIEE_BIPLATFORM/Admin123@PDBORCL"
MYPATH="/app/oracle/SAScripts/checkanalyses/upload_results"
#--------------------Cleanup old logs and bad files --------------------
cd $MYPATH
rm -f log/* bad/* 

sqlldr $DBCONNECTION control=ctl/load-lsql-out.ctl log=log/load-lsql-out.log

#--------------------Printing logs--------------------
tail log/*
#--------------------End of Script --------------------
