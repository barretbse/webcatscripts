---------------------------------------------------------------------------------
NOTE: 
1. This application can be run by simply executing "./runCheck". This script is
executing a jar file details of which are given below. Edit the "runCheck"
file and set it to the right parameters before starting.

2. WLS and all BI Services should be up and running for the checker to work.

3. It generates a tab delimited output text file. The last column in the
output file indicates errors. 

4. Use the load scripts to upload the checker results into database. 
---------------------------------------------------------------------------------

Usage: 
 java -jar CheckAnalyses.jar ["-lsql" | "-exec"] "<hostname>" "<port number>" "<username>" "<password>" "<catalog path>"

Example: 
 java -jar CheckAnalyses.jar "-lsql" "localhost" "7780" "weblogic" "Admin123" "/shared/folder1"
 java -jar CheckAnalyses.jar "-exec" "localhost" "7780" "weblogic" "Admin123" "/shared/folder2"

Purpose:
Verifies the integrity of analyses saved in a presentation catalog. This program connects 
to BI presentation services (via webservices), and recursively identifies the catalog 
objects of the type Analysis and verifies them. There are two execution modes for this -

   -lsql: in this mode, reports that cannot be resolved to a logical SQL are identified. 
     Report is not actually executed and hence this mode executes comparatively quicker.
   
   -exec: reports are executed and number of rows returned by the server are displayed.
     Reports with no results as well as reports with odbc errors will display 0 rows.

