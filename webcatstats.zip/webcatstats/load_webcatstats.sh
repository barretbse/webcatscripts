#!/bin/sh

#--------------------Set env variables--------------------
#IMPORTANT: Key in correct values for the following environment variables

DBCONNECTION="BIEE_BIPLATFORM/Admin123@PDBORCL"
WEBCATSTATS_PATH="/app/oracle/SAScripts/webcatstats"

#--------------------Cleanup old logs and bad files --------------------
cd $WEBCATSTATS_PATH
rm -f log/* bad/* 

sqlldr $DBCONNECTION control=ctl/Analysis.ctl log=log/Analysis.log
sqlldr $DBCONNECTION control=ctl/Dashboard.ctl log=log/Dashboard.log
sqlldr $DBCONNECTION control=ctl/Prompt.ctl log=log/Prompt.log
sqlldr $DBCONNECTION control=ctl/Filter.ctl log=log/Filter.log
sqlldr $DBCONNECTION control=ctl/AllObjects.ctl log=log/AllObjects.log

#--------------------Printing logs--------------------
tail log/*

#--------------------End of Script --------------------
