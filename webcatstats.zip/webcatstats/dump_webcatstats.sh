#!/bin/sh

#--------------------Set env variables--------------------
#IMPORTANT: Key in correct values for the following environment variables

CATALOGPATH="/app/oracle/biee/user_projects/domains/bi/bidata/service_instances/ssi/metadata/content/catalog"
RUNCATCMD="/app/oracle/biee/user_projects/domains/bi/bitools/bin/runcat.sh"
REP_PATH="/app/oracle/SAScripts/webcatstats/rep"

#--------------------Constructing few additional vars to be used in the script-----------
REPORTCMD="$RUNCATCMD -cmd report -excelFormat -distinct -offline $CATALOGPATH -outputFile"
CREATEREPMSG="Preparing report on object type -"

#--------------------Cleanup old catalog reports--------------------
cd $REP_PATH
rm -f *.report

#--------------------Create catalog reports--------------------
echo "Preparing report on all objects"
$REPORTCMD $REP_PATH/AllObjects.report -type "All" -fields "Signature:Created:Modified:Owner:Description:Folder:Name:Path"
echo "$CREATEREPMSG Analysis"
$REPORTCMD $REP_PATH/Analysis.report -type "Analysis" -fields "Name:Path:Table:Column:Subject Area"
echo "$CREATEREPMSG Dashboard"
$REPORTCMD $REP_PATH/Dashboard_temp.report -type "Dashboard" -fields "Name:Path:Dashboard Style" -childrenType "Dashboard Page:Analysis" -childrenFields "Signature:Name:Path"
echo "$CREATEREPMSG Dashboard Prompt"
$REPORTCMD $REP_PATH/DBPrompt.report -type "Dashboard Prompt" -fields "Name:Path:Table:Column:Subject Area"
echo "$CREATEREPMSG Filter"
$REPORTCMD $REP_PATH/Filter.report -type "Filter" -fields "Name:Path:Table:Column:Subject Area"

echo ""
echo "INFO: Post processing - STARTED"
/home/oracle/scripts/webcatstats/processDBReport.sh $REP_PATH/Dashboard_temp.report > $REP_PATH/Dashboard.report
echo "INFO: Post processing - COMPLETED"

#--------------------End of Script --------------------
