
Webcat Statistics Scripts SampleApp 
===================================

A - Purpose:
------------
1. create_webcatstats_schema.sql : this script creates db schema objects required for loading webcat statistics data.
2. dump_webcatstats : this script executes OBIEE catalog manager to dump Presentation catalog information into flat files. These files are saved under /rep directory.
3. load_webcatstats : this script leverages sqlldr (SQL Loader) to parse and load the catalog manager reports (output from previous script) on to selected database.


B - Initial Install :
---------------------
1. Unzip the Webcatstats directory and all its content on your OBIEE SampleApp server file structure (for exp, C:/webcatstats/
2. Edit each of the 3 scripts and update the environment variables under "---Set env variables---" section in each scripts to correct values that would work in your environment. 
3. Make sure sqlldr (SQL Loader) is available on your system and include the path to sqlldr to your enviroment path settings
4. Make sure you have an catalog manager installation (which comes as part of OBIEE installation) on your system



C - Usage:
----------
Execute the scripts in the sequence listed in the above section. 
- For first execution, you need to run the create_webcatstats_schema.sql first, then dump_webcatstats and load_webcatstats in that order.
- For subsequent execution (refreshs), you only need to run dump_webcatstats and load_webcatstats in that order.

				================

