#!/bin/bash

IFS=$'\t'
INPUTFILE=$1
rowno=1

while read Name Path Style ChildType ChildName ChildPath; do
    if [ $rowno == 1 ]; then
        rowno=2
        continue
    fi
    
#    if [ $rowno > 2 ]; then
		if [[ "$ChildType" == "\"Dashboard Page\"" && "$prevChildType" == "\"Dashboard Page\"" ]]; then
				echo -e "$prevName\t$prevPath\t$prevStyle\t$prevChildName\t$prevChildPath\t\"\"\t\"\""
		fi
		
		if [ "$ChildType" == "\"Dashboard Page\"" ]; then
				lastDBPageName=$ChildName
				lastDBPagePath=$ChildPath
		fi
		
		if [ "$ChildType" == "\"Analysis\"" ]; then
				echo -e "$Name\t$Path\t$Style\t$lastDBPageName\t$lastDBPagePath\t$ChildName\t$ChildPath"
		fi
#    fi
    
    prevName=$Name
    prevPath=$Path
    prevStyle=$Style
    prevChildType=$ChildType
    prevChildName=$ChildName
    prevChildPath=$ChildPath
    rowno=$((rowno+1))
done < $INPUTFILE

if [ "$prevChildType" == "\"Dashboard Page\"" ]; then
    echo -e "$prevName\t$prevPath\t$prevStyle\t$prevChildName\t$prevChildPath\t\"\"\t\"\""
fi
