#!/bin/sh

#--------------------Set env variables--------------------
#IMPORTANT: Key in correct values for the following environment variables

DBCONNECTION="BIEE_BIPLATFORM/Admin123@PDBORCL"
MYPATH="/app/oracle/SAScripts/ACLDump"
#--------------------Cleanup old logs and bad files --------------------
cd $MYPATH
rm -f log/* bad/* 

sqlldr $DBCONNECTION control=ctl/load_acldump.ctl log=log/load_acldump.log

#--------------------Printing logs--------------------
tail log/*
#--------------------End of Script --------------------
