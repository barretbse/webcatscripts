This utility iterates through each Presentation Catalog object and lists out its Access Control List, other security attributes and permissions. List of fields included in its output are listed below. 

Execute "dump_ACL.sh" to dump the ACL info to a tab delimited text file. Then run "load_results.sh" file to upload its result into database. BI reports built on top of this data are saved under "/shared/9. Lifecycle and Admin/_portal/9.32 Webcat Permissions"

Catalog Object Details:
 - ObjectName      
 - ObjectPath      
 - Path-Level0     
 - Path-Level1     
 - Path-Level2     
 - Path-Rest       
 - ObjectType      
 - Owner   

Security Account Info:
 - Account
 - AccountType     

Permissions:
 - Read  
 - Execute
 - Write   
 - Delete  
 - ChangePermissions   
 - SetOwnership     
 - RunPublisherReport      
 - SchedulePublisherReport 
 - ViewPublisherOutput

